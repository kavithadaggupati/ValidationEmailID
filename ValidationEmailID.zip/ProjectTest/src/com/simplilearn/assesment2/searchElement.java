package com.simplilearn.assesment2;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;


public class searchElement 
{

    public static void main(String[] args) 
    {
        
        ArrayList<String> emailID = new ArrayList<String>();
        
        String regex = "[\\w-]{1,20}@\\w{2,20}\\.\\w{2,3}$";
             
        emailID.add("vani@gmail.com");
        emailID.add("srilatha12@gmail.com");
        emailID.add("kavitha@gmail.com");
        emailID.add("rajyalaxmi@gmail.com");
        emailID.add("Srinu@gmail.com");
        emailID.add("dss123@gmail.com");
        emailID.add("bhalamukundar@gmail.com");
          
         String searcElement = null;
          for(int i=0; i<emailID.size(); i++)
            {
                System.out.println(emailID.get(i));
                    
                if(searcElement==emailID.get(i))
                    {
                        
                        System.out.println("\n");
                        
                        System.out.println("email ID" + searcElement + "found");
                        
                        break;
                    }
            }
         
          System.out.println("\n");
          System.out.println("Enter the email to search");
          
          Scanner sc = new Scanner(System.in);
          String searchElement = sc.nextLine();
          Matcher matcher = Pattern.compile(regex).matcher(searchElement);
          
           if (matcher.matches() && emailID.stream().anyMatch(mail -> mail.equals(searchElement))) 
                 {
                     System.out.println(searchElement + " = is present");
                 } 
                 else
                 {
                     System.out.println("\nNot a valid emailid");
                 }
                   
  
    }

}
